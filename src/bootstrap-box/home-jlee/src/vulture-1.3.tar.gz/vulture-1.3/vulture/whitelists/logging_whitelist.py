import logging

logging.Filter.filter
logging.StreamHandler.emit
