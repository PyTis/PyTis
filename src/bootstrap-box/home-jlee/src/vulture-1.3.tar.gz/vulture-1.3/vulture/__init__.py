from vulture.core import __version__, Vulture

assert __version__
assert Vulture
